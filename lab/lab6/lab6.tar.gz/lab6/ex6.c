#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{
    char fmtstr[64];
    char secret[8] = "findme";
    char junk[100] = "some random stuff to fill the stack";

    printf("Address of fmtstr: %p\n", fmtstr);
    printf("Address of secret: %p\n", secret);
    
    printf("Input a format string: ");
    fgets(fmtstr, 64, stdin);
    printf(fmtstr);

    return 0;
}

