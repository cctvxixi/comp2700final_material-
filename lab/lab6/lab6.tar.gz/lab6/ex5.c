#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    int n = 0;
    int guess;
    int helper=0x12345678; // use this value to find the location of guess 
    char str[64]="What is your guess? ";
    char answer[16];

    printf("Address of n: %p\n", &n);
    printf("Address of guess: %p\n", &guess);
    printf("Address of helper: %p\n", &helper);
    srand(time(0));
    guess = rand();
    do {
        printf(str);
        fgets(answer,16,stdin);
        printf("Your answer: ");
        printf(answer);
        n = atoi(answer);
        if(n == guess) {
            printf(" is correct!\n");
            break;
        }
        printf(" is wrong!\n");
        printf("Guess again (y/n)? ");
        fgets(answer,3,stdin);
    }
    while(answer[0] == 'y');
    return 0;
}

