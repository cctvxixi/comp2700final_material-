#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    char a = 'a';
    char *buffer;

    if(argc < 2){
        printf("Usage: %s <string>\n", argv[0]);
        exit(1);
    }

    buffer=(char *) malloc(16);

    if(buffer == NULL) {
        printf("Memory allocation failed\n");
        exit(1);
    }

    printf("Address of a: %p\n", &a);
    printf("Address of buffer: %p\n", buffer);

    strcpy(buffer, argv[1]);
    printf("Value of a: %c\n", a);

    free(buffer);

    return 0;
}

