#include <stdio.h>
#include <string.h>

void print_message(char * msg)
{
  char secret[8] = "SECRET";
  char buffer[15];
  strncpy(buffer, msg, 15);
  printf("Message: %s\n", buffer);
}

int main(int argc, char* argv[])
{
  if(argc < 2) {
     printf("Usage: %s <message>\n", argv[0]); 
     return 0;
  }
  print_message(argv[1]);
}

